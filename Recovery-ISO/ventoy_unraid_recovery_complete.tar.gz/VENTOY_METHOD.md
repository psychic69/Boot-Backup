# VENTOY METHOD - THE BEST SOLUTION FOR YOUR USE CASE

## Why Ventoy is Better

✅ **Multi-boot** - Keep SystemRescue + other ISOs on same USB
✅ **No ISO modification** - Just drop files alongside the ISO
✅ **Repeatable** - Update script without rebuilding anything
✅ **User-friendly** - Scripts auto-inject into SystemRescue
✅ **Writable** - Easy to update/modify scripts anytime
✅ **Universal** - Works with any bootable ISO

## How It Works

1. **Ventoy** creates a bootable USB with a menu
2. You drop **SystemRescue ISO** onto the USB
3. You drop your **script** into a special folder
4. **Ventoy injects** the script into SystemRescue at boot
5. **SystemRescue autorun** executes your script automatically

## Complete Setup Process

### Step 1: Install Ventoy (5 minutes, ONE TIME)

**Windows:**
1. Download Ventoy: https://github.com/ventoy/Ventoy/releases
2. Extract and run `Ventoy2Disk.exe`
3. Select your USB drive
4. Click "Install"
5. Done!

**Linux:**
```bash
# Download and extract
wget https://github.com/ventoy/Ventoy/releases/download/v1.0.99/ventoy-1.0.99-linux.tar.gz
tar -xzf ventoy-1.0.99-linux.tar.gz
cd ventoy-1.0.99

# Install to USB (replace /dev/sdX with your USB device)
sudo ./Ventoy2Disk.sh -i /dev/sdX
```

**Mac:**
```bash
# Download and extract (same as Linux)
# Then:
sudo ./Ventoy2Disk.sh -i /dev/diskX
```

### Step 2: Download SystemRescue ISO (5 minutes, ONE TIME)

Download from: https://www.system-rescue.org/Download/

Save it for later - you'll copy it to the USB.

### Step 3: Set Up the Script Injection (2 minutes)

After Ventoy is installed, your USB will have a large partition called "Ventoy".

Create this folder structure on the Ventoy partition:

```
Ventoy (USB Drive)
├── systemrescue-11.01-amd64.iso  (your downloaded ISO)
├── ventoy/
│   ├── ventoy.json               (configuration file)
│   └── sysrescue_injection/      (injection folder)
│       └── sysrescue.d/
│           └── autorun/
│               ├── move_DR_to_UNRAID.sh
│               └── 00-launcher.sh
```

### Step 4: Copy Files to USB

See the accompanying script: `setup_ventoy_usb.sh` 
Or do it manually:

1. **Copy SystemRescue ISO** to USB root:
   ```
   Copy systemrescue-11.01-amd64.iso to Ventoy:/
   ```

2. **Create injection structure:**
   ```
   Ventoy:/ventoy/sysrescue_injection/sysrescue.d/autorun/
   ```

3. **Copy scripts:**
   - Copy `move_DR_to_UNRAID.sh` to autorun folder
   - Copy `00-launcher.sh` to autorun folder

4. **Create ventoy.json:**
   Copy the provided `ventoy.json` to `Ventoy:/ventoy/`

## What Happens When User Boots

1. **Boot USB** → Ventoy menu appears
2. **Select SystemRescue** → ISO boots
3. **Ventoy auto-injects** your scripts into `/sysrescue.d/autorun/`
4. **SystemRescue auto-runs** `00-launcher.sh`
5. **User sees friendly menu** and follows prompts
6. **Done!** - No typing commands needed

## Advantages Over Previous Methods

| Feature | Ventoy | Custom ISO | Simple Injection |
|---------|--------|------------|------------------|
| Setup Time | 10 min | 30 min | 15 min |
| User Experience | Perfect | Perfect | Good |
| Easy to Update | ⭐⭐⭐⭐⭐ | ⭐ | ⭐⭐⭐ |
| Multi-boot | ✅ Yes | ❌ No | ❌ No |
| No Rebuild Needed | ✅ Yes | ❌ No | ⭐ Sometimes |
| Truly Auto-run | ✅ Yes | ✅ Yes | ❌ No |

## Updating Your Script

This is where Ventoy REALLY shines:

```bash
# Just replace the script file!
# No ISO rebuild, no re-flashing, nothing complex

# 1. Plug in Ventoy USB
# 2. Replace the file:
cp new_move_DR_to_UNRAID.sh /media/Ventoy/ventoy/sysrescue_injection/sysrescue.d/autorun/
# 3. Done!
```

## Adding More ISOs

Want to add Windows PE, Ubuntu, or other recovery tools?

```bash
# Just copy more ISOs to the USB root
cp ubuntu-24.04-desktop-amd64.iso /media/Ventoy/
cp windows10.iso /media/Ventoy/

# Ventoy auto-detects them and adds to boot menu!
```

## Distribution Options

### Option A: Give User a Pre-configured USB
- Install Ventoy once
- Set up everything
- Hand it to user
- They just boot and select SystemRescue

### Option B: Distribute Setup Package
- Give user:
  1. Ventoy installer
  2. SystemRescue ISO
  3. Your script package
  4. Simple setup instructions
- They run one setup script
- Done forever!

### Option C: Remote Instructions
- User installs Ventoy (easy, GUI)
- User downloads SystemRescue ISO
- You send them the script package
- They run setup script
- Ready to go!

## Files Provided

1. **`setup_ventoy_usb.sh`** - Automated setup script
2. **`ventoy.json`** - Ventoy configuration
3. **`00-launcher.sh`** - User-friendly launcher
4. **`move_DR_to_UNRAID.sh`** - Your recovery script
5. **`VENTOY_USER_GUIDE.txt`** - Simple user instructions

## Testing

1. Boot in VM or test machine
2. Select SystemRescue from Ventoy menu
3. Verify script runs automatically
4. Test with dummy USB drives

## Troubleshooting

**Script doesn't run automatically?**
- Check ventoy.json is in correct location
- Verify file paths in ventoy.json
- Make sure scripts are executable
- Check SystemRescue autorun logs: `/var/log/sysrescue-autorun.log`

**Ventoy menu doesn't show SystemRescue?**
- ISO must be in Ventoy partition root
- ISO must be valid (check with `file` command)
- Try renaming ISO to simple name: `sysrescue.iso`

**Changes don't take effect?**
- Make sure you're editing files on Ventoy partition
- Sync after changes: `sync`
- Try safe removal and replug USB

## Summary

**Ventoy is the PERFECT solution for your use case because:**

1. ✅ Setup once, update forever
2. ✅ No ISO rebuilding ever needed
3. ✅ True auto-run capability
4. ✅ Multi-boot bonus feature
5. ✅ Non-technical user friendly
6. ✅ Professional and repeatable

**Your workflow:**
1. Install Ventoy (once)
2. Run `setup_ventoy_usb.sh` (once)
3. Update scripts anytime by just copying files
4. User boots → auto-runs → done!

---

**Bottom Line:** Use Ventoy. It's specifically designed for this exact use case.
