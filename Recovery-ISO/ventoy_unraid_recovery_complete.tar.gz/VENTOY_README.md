# VENTOY SOLUTION FOR UNRAID USB RECOVERY

## 🎯 The Best Solution for Your Needs

After analyzing your requirements, **Ventoy is the optimal solution**. Here's why:

✅ **Non-technical users** - Script runs automatically, no commands needed
✅ **Easy and repeatable** - Update by copying one file (30 seconds)
✅ **Professional** - Clean boot menu, reliable operation
✅ **Bonus features** - Multi-boot capability, can add more tools
✅ **Future-proof** - Easy to maintain and update

## 📦 What's Included

### Core Files
- **`setup_ventoy_usb.sh`** - Automated setup script (run once)
- **`ventoy.json`** - Ventoy configuration file
- **`move_DR_to_UNRAID.sh`** - Your original recovery script

### Documentation
- **`VENTOY_METHOD.md`** - Complete Ventoy method guide
- **`VENTOY_COMPARISON.md`** - Detailed comparison with other methods
- **`VENTOY_USER_GUIDE.txt`** - Simple guide for end users (print-friendly)

## 🚀 Quick Start (5 Steps)

### Step 1: Install Ventoy (ONE TIME)

**Windows:**
1. Download: https://github.com/ventoy/Ventoy/releases
2. Extract and run `Ventoy2Disk.exe`
3. Select USB drive
4. Click "Install"

**Linux/Mac:**
```bash
wget https://github.com/ventoy/Ventoy/releases/download/v1.0.99/ventoy-1.0.99-linux.tar.gz
tar -xzf ventoy-1.0.99-linux.tar.gz
cd ventoy-1.0.99
sudo ./Ventoy2Disk.sh -i /dev/sdX  # Replace sdX with your USB
```

### Step 2: Run Setup Script

```bash
# Make sure these files are in the same directory:
# - setup_ventoy_usb.sh
# - move_DR_to_UNRAID.sh
# - ventoy.json

bash setup_ventoy_usb.sh
```

The script will:
- Download SystemRescue ISO (if needed)
- Set up directory structure
- Copy your recovery script
- Create launcher script
- Generate Ventoy configuration
- Create injection archive

### Step 3: Test It

Boot from the USB in a VM or test machine to verify everything works.

### Step 4: Give to User

Hand them the USB with the user guide (`VENTOY_USER_GUIDE.txt`).

### Step 5: Done!

**User experience:**
1. Boot from USB
2. Select "Unraid Recovery" from menu
3. Script runs automatically
4. Follow prompts
5. Done!

## 🔄 Updating Your Script

This is where Ventoy really shines:

```bash
# 1. Mount your Ventoy USB
# 2. Replace the script file:
cp new_move_DR_to_UNRAID.sh /media/Ventoy/ventoy/sysrescue_injection/sysrescue.d/autorun/

# 3. Rebuild the injection archive:
cd /media/Ventoy/ventoy/sysrescue_injection
tar -czf ../sysrescue_injection.tar.gz sysrescue.d/

# 4. Sync and eject
sync

# That's it! 30 seconds total.
```

**No ISO rebuilding, no re-flashing, no complexity!**

## 📊 Comparison with Other Methods

| Feature | Ventoy | Custom ISO | Simple Injection |
|---------|--------|------------|------------------|
| Setup Time | 10 min | 30 min | 15 min |
| User Commands | None | None | One command |
| Update Time | 30 sec | 30 min rebuild | 30 sec |
| Multi-boot | ✅ Yes | ❌ No | ❌ No |
| Auto-run | ✅ Yes | ✅ Yes | ❌ No |
| Repeatable | ⭐⭐⭐⭐⭐ | ⭐ | ⭐⭐⭐ |

**Winner: Ventoy** for your use case! See `VENTOY_COMPARISON.md` for full analysis.

## 🎓 How It Works

1. **Ventoy** creates a multi-boot USB with a menu
2. You drop **SystemRescue ISO** onto the USB
3. You create an **injection archive** with your scripts
4. At boot, **Ventoy injects** scripts into SystemRescue
5. **SystemRescue autorun** executes your script automatically

**Result:** Professional, maintainable, user-friendly recovery USB!

## 📂 Directory Structure

After setup, your Ventoy USB looks like this:

```
Ventoy (USB Drive)
├── systemrescue-11.01-amd64.iso
├── UNRAID_RECOVERY_INSTRUCTIONS.txt
└── ventoy/
    ├── ventoy.json
    ├── sysrescue_injection.tar.gz
    └── sysrescue_injection/
        └── sysrescue.d/
            └── autorun/
                ├── move_DR_to_UNRAID.sh
                └── 00-launcher.sh
```

## 🎯 Use Cases

### Scenario 1: Single User (In-Person)
1. Set up one Ventoy USB (10 min)
2. Give USB + printed guide to user
3. Done!

### Scenario 2: Multiple Users (Remote)
1. Set up one master Ventoy USB (10 min)
2. Clone to multiple USBs (disk imaging)
3. Ship to users
4. Script updates? Email new script (5KB)
5. Users copy to USB (30 sec)

### Scenario 3: IT Department
1. Set up one Ventoy USB (10 min)
2. Add other rescue tools (Windows PE, Ubuntu, etc.)
3. Maintain one USB for all recovery needs
4. Update any tool by copying files
5. Professional multi-tool rescue USB!

## 🔧 Advanced Features

### Adding More ISOs

Want to add Windows PE or Ubuntu?

```bash
# Just copy more ISOs to USB root
cp windows_pe.iso /media/Ventoy/
cp ubuntu-24.04.iso /media/Ventoy/

# Ventoy automatically adds them to menu!
```

### Customizing the Menu

Edit `/media/Ventoy/ventoy/ventoy.json`:

```json
{
  "menu_alias": [
    {
      "image": "/systemrescue-11.01-amd64.iso",
      "alias": "🔧 Unraid Recovery (Auto)"
    },
    {
      "image": "/ubuntu-24.04.iso",
      "alias": "🐧 Ubuntu Live"
    }
  ],
  "theme": {
    "display_mode": "GUI",
    "ventoy_color": "#00ff00"
  }
}
```

### Creating Persistence

Want to save data between boots?

```bash
# Create 4GB persistence file
dd if=/dev/zero of=/media/Ventoy/persistence.dat bs=1M count=4096
mkfs.ext4 /media/Ventoy/persistence.dat

# Add to ventoy.json
{
  "persistence": [
    {
      "image": "/systemrescue-11.01-amd64.iso",
      "backend": "/persistence.dat"
    }
  ]
}
```

## 🆘 Troubleshooting

### Setup Script Issues

**"Can't find Ventoy USB"**
```bash
# Manually specify mount point:
bash setup_ventoy_usb.sh /media/YOUR_USERNAME/Ventoy
```

**"SystemRescue ISO not found"**
```bash
# Download manually:
wget https://sourceforge.net/projects/systemrescuecd/files/sysrescue/11.01/systemrescue-11.01-amd64.iso
# Then run setup script again
```

### Boot Issues

**"Ventoy menu doesn't appear"**
- Try different USB port
- Check BIOS boot order
- Try Legacy vs UEFI mode

**"Script doesn't auto-run"**
- Check injection archive was created
- Verify ventoy.json paths are correct
- Check SystemRescue logs: `/var/log/sysrescue-autorun.log`

### Script Issues

**"UNRAID_DR not found"**
- Ensure backup USB is plugged in
- Check USB label is exactly "UNRAID_DR"
- Wait 10 seconds and try again

**"UNRAID already exists"**
- Remove any USB drives labeled "UNRAID"
- Only backup USB should be connected

## 📚 Additional Resources

- **Ventoy Documentation**: https://www.ventoy.net/
- **SystemRescue Manual**: https://www.system-rescue.org/manual/
- **Ventoy GitHub**: https://github.com/ventoy/Ventoy
- **SystemRescue Autorun**: https://www.system-rescue.org/manual/Run_your_own_scripts_with_autorun/

## 💡 Pro Tips

1. **Label your USB**: Write "Unraid Recovery" on the physical USB
2. **Include instructions**: Print `VENTOY_USER_GUIDE.txt` on card stock
3. **Test regularly**: Boot from USB quarterly to ensure it works
4. **Keep backup**: Clone your master USB periodically
5. **Update SystemRescue**: Drop new ISO on USB when released

## 🎉 Summary

**What You Get:**
- Professional recovery USB
- Auto-run capability (no user commands)
- 30-second script updates
- Multi-boot bonus feature
- Future-proof solution

**Setup Time:** 10 minutes once
**Update Time:** 30 seconds
**User Experience:** Excellent
**Maintainability:** Perfect

**This is the ideal solution for your use case!**

---

## Quick Reference Commands

```bash
# Setup Ventoy USB
bash setup_ventoy_usb.sh

# Update script only
cp new_script.sh /media/Ventoy/ventoy/sysrescue_injection/sysrescue.d/autorun/move_DR_to_UNRAID.sh
cd /media/Ventoy/ventoy/sysrescue_injection
tar -czf ../sysrescue_injection.tar.gz sysrescue.d/
sync

# Add new ISO
cp new_tool.iso /media/Ventoy/

# Check Ventoy version
/media/Ventoy/ventoy/version
```

---

**Created:** October 2025
**Package Version:** 1.0
**Ventoy Version:** 1.0.99
**SystemRescue Version:** 11.01

🚀 Ready to get started? Run `bash setup_ventoy_usb.sh`!
