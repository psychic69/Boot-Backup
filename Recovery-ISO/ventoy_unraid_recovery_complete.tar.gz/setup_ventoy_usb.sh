#!/bin/bash

# Automated Ventoy USB Setup for Unraid Recovery
# This script sets up a Ventoy USB with SystemRescue and your recovery script

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENTOY_LABEL="Ventoy"
SYSRESCUE_ISO="systemrescue-11.01-amd64.iso"
SYSRESCUE_URL="https://sourceforge.net/projects/systemrescuecd/files/sysrescue/11.01/${SYSRESCUE_ISO}/download"

echo "╔════════════════════════════════════════════════════╗"
echo "║  Ventoy USB Setup for Unraid Recovery             ║"
echo "╚════════════════════════════════════════════════════╝"
echo

# Check if move_DR_to_UNRAID.sh exists
if [ ! -f "$SCRIPT_DIR/move_DR_to_UNRAID.sh" ]; then
    echo "❌ ERROR: move_DR_to_UNRAID.sh not found!"
    echo "   Please make sure it's in the same directory as this script."
    exit 1
fi

# Find Ventoy USB partition
echo "Looking for Ventoy USB drive..."
VENTOY_MOUNT=""

# Try different mount locations
for mount_point in /media/$USER/$VENTOY_LABEL /media/$VENTOY_LABEL /run/media/$USER/$VENTOY_LABEL /mnt/$VENTOY_LABEL; do
    if [ -d "$mount_point" ]; then
        VENTOY_MOUNT="$mount_point"
        break
    fi
done

# If not found, ask user
if [ -z "$VENTOY_MOUNT" ]; then
    echo "❓ Could not auto-detect Ventoy USB mount point."
    echo
    read -p "Enter Ventoy USB mount point (e.g., /media/$USER/Ventoy): " VENTOY_MOUNT
    
    if [ ! -d "$VENTOY_MOUNT" ]; then
        echo "❌ Directory does not exist: $VENTOY_MOUNT"
        exit 1
    fi
fi

echo "✅ Found Ventoy USB at: $VENTOY_MOUNT"
echo

# Check if SystemRescue ISO exists
if [ ! -f "$SCRIPT_DIR/$SYSRESCUE_ISO" ]; then
    echo "📥 SystemRescue ISO not found. Download it?"
    echo "   Size: ~800MB"
    read -p "Download now? (yes/no): " download_response
    
    if [[ "$download_response" =~ ^[Yy][Ee][Ss]$ ]]; then
        echo "Downloading SystemRescue..."
        wget -O "$SCRIPT_DIR/$SYSRESCUE_ISO" "$SYSRESCUE_URL"
        echo "✅ Download complete"
    else
        echo "❌ SystemRescue ISO required. Please download manually:"
        echo "   https://www.system-rescue.org/Download/"
        exit 1
    fi
fi

echo
echo "Setting up Ventoy USB structure..."
echo "─────────────────────────────────────────────────────"

# Create injection directory structure
INJECTION_DIR="$VENTOY_MOUNT/ventoy/sysrescue_injection"
AUTORUN_DIR="$INJECTION_DIR/sysrescue.d/autorun"

echo "Creating directories..."
mkdir -p "$AUTORUN_DIR"

# Copy SystemRescue ISO to USB root
echo "Copying SystemRescue ISO to USB..."
if [ -f "$VENTOY_MOUNT/$SYSRESCUE_ISO" ]; then
    echo "  (ISO already exists, skipping)"
else
    cp "$SCRIPT_DIR/$SYSRESCUE_ISO" "$VENTOY_MOUNT/"
    echo "  ✅ ISO copied"
fi

# Copy recovery script
echo "Copying recovery script..."
cp "$SCRIPT_DIR/move_DR_to_UNRAID.sh" "$AUTORUN_DIR/"
chmod +x "$AUTORUN_DIR/move_DR_to_UNRAID.sh"
echo "  ✅ Recovery script copied"

# Create launcher script
echo "Creating launcher script..."
cat > "$AUTORUN_DIR/00-launcher.sh" << 'LAUNCHER_EOF'
#!/bin/bash
clear
echo "╔══════════════════════════════════════════════════╗"
echo "║                                                  ║"
echo "║        UNRAID USB RECOVERY TOOL                  ║"
echo "║                                                  ║"
echo "╚══════════════════════════════════════════════════╝"
echo
echo "This tool will restore your Unraid USB drive"
echo "from a backup labeled 'UNRAID_DR'"
echo
echo "CHECKLIST:"
echo "  ☐ Backup USB (UNRAID_DR) is plugged in"
echo "  ☐ Any existing UNRAID USB drives are removed"
echo "  ☐ You're ready to proceed"
echo
echo "──────────────────────────────────────────────────"
read -p "Continue? (yes/no): " response
echo

if [[ "$response" =~ ^[Yy][Ee][Ss]$ ]]; then
    bash /sysrescue.d/autorun/move_DR_to_UNRAID.sh
    
    echo
    echo "╔══════════════════════════════════════════════════╗"
    echo "║  ✅ RECOVERY COMPLETE!                           ║"
    echo "╚══════════════════════════════════════════════════╝"
    echo
    echo "Next steps:"
    echo "  1. Type 'poweroff' to shut down"
    echo "  2. Remove this recovery USB"
    echo "  3. Boot normally from your restored Unraid USB"
    echo
else
    echo "Recovery cancelled. Type 'poweroff' to shut down."
fi
LAUNCHER_EOF

chmod +x "$AUTORUN_DIR/00-launcher.sh"
echo "  ✅ Launcher script created"

# Create ventoy.json configuration
echo "Creating Ventoy configuration..."
VENTOY_JSON="$VENTOY_MOUNT/ventoy/ventoy.json"

# Check if ventoy.json already exists
if [ -f "$VENTOY_JSON" ]; then
    echo "  ⚠️  ventoy.json already exists"
    read -p "  Overwrite? (yes/no): " overwrite_response
    if [[ ! "$overwrite_response" =~ ^[Yy][Ee][Ss]$ ]]; then
        echo "  ⚠️  Skipping ventoy.json creation"
        echo "  You'll need to manually add the injection configuration"
        echo
        echo "  Add this to your ventoy.json:"
        echo "  {"
        echo "    \"injection\": ["
        echo "      {"
        echo "        \"image\": \"/$SYSRESCUE_ISO\","
        echo "        \"archive\": \"/ventoy/sysrescue_injection.tar.gz\""
        echo "      }"
        echo "    ]"
        echo "  }"
        SKIP_VENTOY_JSON=true
    fi
fi

if [ "$SKIP_VENTOY_JSON" != "true" ]; then
    cat > "$VENTOY_JSON" << EOF
{
  "control": [
    {
      "VTOY_DEFAULT_SEARCH_ROOT": "/",
      "VTOY_MENU_TIMEOUT": 30
    }
  ],
  "injection": [
    {
      "image": "/$SYSRESCUE_ISO",
      "archive": "/ventoy/sysrescue_injection.tar.gz"
    }
  ],
  "menu_alias": [
    {
      "image": "/$SYSRESCUE_ISO",
      "alias": "Unraid Recovery - SystemRescue (Auto-run)"
    }
  ]
}
EOF
    echo "  ✅ ventoy.json created"
fi

# Create the injection archive
echo "Creating injection archive..."
cd "$INJECTION_DIR"
tar -czf "$VENTOY_MOUNT/ventoy/sysrescue_injection.tar.gz" sysrescue.d/
cd "$SCRIPT_DIR"
echo "  ✅ Injection archive created"

# Create user instructions
echo "Creating user instructions..."
cat > "$VENTOY_MOUNT/UNRAID_RECOVERY_INSTRUCTIONS.txt" << 'INSTRUCTIONS_EOF'
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║       UNRAID USB RECOVERY - VENTOY EDITION                ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝

WHAT THIS USB DOES
──────────────────
This USB contains SystemRescue with an automated Unraid USB
recovery script that will restore your Unraid drive from backup.

BEFORE YOU START
────────────────
✓ Plug in your backup USB (labeled "UNRAID_DR")
✓ Remove any USB drives labeled "UNRAID"
✓ Have this Ventoy USB ready

HOW TO USE
──────────
1. INSERT this USB drive into your computer

2. RESTART and press the boot menu key:
   Common keys: F12, F11, F8, ESC, or DEL

3. SELECT this USB drive from the boot menu

4. CHOOSE "Unraid Recovery - SystemRescue" from Ventoy menu
   (Use arrow keys to navigate, Enter to select)

5. WAIT for SystemRescue to boot (30-60 seconds)
   The recovery script will start AUTOMATICALLY!

6. FOLLOW the on-screen instructions:
   - Read the checklist
   - Type "yes" to confirm
   - Wait for completion

7. WHEN YOU SEE "✅ RECOVERY COMPLETE":
   - Type: poweroff
   - Remove this USB
   - Boot normally from your Unraid USB

TROUBLESHOOTING
───────────────
• Can't see boot menu?
  → Press the boot key repeatedly during startup

• Ventoy menu doesn't appear?
  → Try a different USB port
  → Check BIOS boot order

• Script doesn't run?
  → It should start automatically
  → Check the screen for any error messages

• Need to cancel?
  → Type "no" when prompted
  → Type "poweroff" to shut down

TECHNICAL DETAILS
─────────────────
This USB uses Ventoy for multi-boot capability.
Scripts are auto-injected into SystemRescue at boot.
Your recovery script: /sysrescue.d/autorun/move_DR_to_UNRAID.sh

For support: Check your IT department or Unraid forums
───────────────────────────────────────────────────────────
INSTRUCTIONS_EOF

echo "  ✅ User instructions created"

# Sync filesystem
echo
echo "Syncing filesystem..."
sync

echo
echo "╔════════════════════════════════════════════════════╗"
echo "║  ✅ SETUP COMPLETE!                                ║"
echo "╚════════════════════════════════════════════════════╝"
echo
echo "Your Ventoy USB is ready!"
echo
echo "USB Contents:"
echo "  📁 $VENTOY_MOUNT/"
echo "  ├── $SYSRESCUE_ISO"
echo "  ├── UNRAID_RECOVERY_INSTRUCTIONS.txt"
echo "  └── ventoy/"
echo "      ├── ventoy.json"
echo "      ├── sysrescue_injection.tar.gz"
echo "      └── sysrescue_injection/"
echo "          └── sysrescue.d/autorun/"
echo "              ├── move_DR_to_UNRAID.sh"
echo "              └── 00-launcher.sh"
echo
echo "WHAT TO DO NOW:"
echo "  1. Safely eject/unmount the USB"
echo "  2. Give it to your user with the instructions"
echo "  3. They boot from USB → Select SystemRescue → Auto-runs!"
echo
echo "TO UPDATE THE SCRIPT LATER:"
echo "  1. Mount the Ventoy USB"
echo "  2. Replace: $VENTOY_MOUNT/ventoy/sysrescue_injection/sysrescue.d/autorun/move_DR_to_UNRAID.sh"
echo "  3. Recreate archive: cd $VENTOY_MOUNT/ventoy/sysrescue_injection && tar -czf ../sysrescue_injection.tar.gz sysrescue.d/"
echo "  4. Sync and eject"
echo
echo "═══════════════════════════════════════════════════════"
