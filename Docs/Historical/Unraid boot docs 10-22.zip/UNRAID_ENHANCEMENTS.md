# Unraid-Specific Enhancements

## What Changed

The setup script now includes **intelligent Unraid detection and handling** for a seamless experience on Unraid systems.

## Key Features

### 1. Automatic Unraid Detection ✅
```bash
# Detects Unraid kernel
uname -a | grep "Unraid"
```

When running on Unraid, you'll see:
```
✅ Detected Unraid system
```

### 2. Smart Ventoy Discovery on Unraid ✅
Uses Unraid-native `lsblk` command to find Ventoy:
```bash
lsblk -b -P -o NAME,UUID,FSTYPE,SIZE,MOUNTPOINT,LABEL,TRAN | grep 'LABEL="Ventoy"'
```

Output example:
```
✅ Found Ventoy device: /dev/sdc1
```

### 3. Unraid-Standard Mount Point ✅
Automatically uses Unraid's convention:
```
/mnt/disks/Ventoy
```

Creates the directory if it doesn't exist:
```
Creating mount point: /mnt/disks/Ventoy
```

### 4. Automatic Mounting ✅
Mounts the Ventoy partition automatically:
```bash
mount /dev/sdc1 /mnt/disks/Ventoy
```

Detects if already mounted:
```
✅ Ventoy already mounted at /mnt/disks/Ventoy
```

### 5. Read-Write Verification ✅
Ensures the mount is writable (critical for downloading ISOs):
```bash
touch /mnt/disks/Ventoy/.write_test
```

Success:
```
✅ Ventoy mount is read-write
```

Failure (with helpful instructions):
```
❌ ERROR: Ventoy mount is read-only!
   Cannot proceed - we need write access to download ISO and create files.
   Please remount with read-write permissions:
   mount -o remount,rw /dev/sdc1 /mnt/disks/Ventoy
```

### 6. Filename Update ✅
Script now uses lowercase filename:
```
move_dr_to_unraid.sh
```
(Instead of `move_DR_to_UNRAID.sh`)

## How It Works

### Detection Flow

```
1. Check kernel: uname -a
   ├─ Contains "Unraid"? → Unraid mode
   └─ Otherwise → Standard Linux mode

2. Unraid Mode:
   ├─ Run: lsblk -b -P -o NAME,... | grep 'LABEL="Ventoy"'
   ├─ Parse device name from output
   ├─ Set mount point: /mnt/disks/Ventoy
   ├─ Create mount point if needed
   ├─ Check if already mounted
   ├─ Mount if not mounted
   └─ Verify read-write access

3. Standard Linux Mode:
   ├─ Try common mount locations
   ├─ Prompt user if not found
   └─ Verify read-write access
```

## Usage on Unraid

### Standard Workflow
```bash
# 1. SSH into your Unraid server
ssh root@unraid-server

# 2. Navigate to where you have the script
cd /mnt/user/scripts/

# 3. Run the script
bash setup_ventoy_usb_with_sha512.sh

# Output will show:
✅ Detected Unraid system
✅ Found Ventoy device: /dev/sdc1
Creating mount point: /mnt/disks/Ventoy
Mounting Ventoy partition...
✅ Successfully mounted Ventoy at /mnt/disks/Ventoy
Checking if mount is read-write...
✅ Ventoy mount is read-write
```

### If Ventoy Already Mounted
```bash
bash setup_ventoy_usb_with_sha512.sh

# Output:
✅ Detected Unraid system
✅ Found Ventoy device: /dev/sdc1
✅ Ventoy already mounted at /mnt/disks/Ventoy
Checking if mount is read-write...
✅ Ventoy mount is read-write
```

## Compatibility

### Works On:
- ✅ Unraid 6.x
- ✅ Unraid 7.x (when released)
- ✅ Any system with "Unraid" in kernel name
- ✅ Standard Linux distributions (fallback mode)

### Non-Unraid Systems:
The script automatically falls back to standard Linux behavior:
- Tries common mount locations
- Prompts for manual path if needed
- Still verifies write access

## Error Handling

### Ventoy Not Found
```
❌ ERROR: Could not find Ventoy partition on Unraid system
   Please ensure Ventoy USB is plugged in
```

**Solution:** Plug in the Ventoy USB and run again

### Mount Failed
```
❌ ERROR: Failed to mount Ventoy device
```

**Solution:** Check device permissions and try manually:
```bash
mount /dev/sdX1 /mnt/disks/Ventoy
```

### Read-Only Mount
```
❌ ERROR: Ventoy mount is read-only!
   Please remount with read-write permissions:
   mount -o remount,rw /dev/sdc1 /mnt/disks/Ventoy
```

**Solution:** Run the provided remount command

## Technical Details

### lsblk Output Format
```
NAME="sdc1" UUID="1234-5678" FSTYPE="vfat" SIZE="31914983424" MOUNTPOINT="" LABEL="Ventoy" TRAN="usb"
```

### Parsing Logic
1. Find line with `LABEL="Ventoy"`
2. Extract `NAME="sdc1"` → Get `sdc1`
3. Construct device path: `/dev/sdc1`
4. Mount to: `/mnt/disks/Ventoy`

### Mount Point Convention
Unraid uses `/mnt/disks/` for unassigned devices:
- Array disks: `/mnt/disk1`, `/mnt/disk2`, etc.
- Cache: `/mnt/cache`
- Unassigned: `/mnt/disks/DeviceName`

## Advantages on Unraid

### Before (Manual Process)
1. ❌ Find Ventoy device manually
2. ❌ Create mount point manually
3. ❌ Mount manually
4. ❌ Remember mount point path
5. ❌ Check write access manually

### After (Automatic)
1. ✅ Run script
2. ✅ Everything detected automatically
3. ✅ Mounted automatically
4. ✅ Verified automatically
5. ✅ Ready to use!

## Example Session

### Complete Unraid Run
```bash
root@Nas:~# bash setup_ventoy_usb_with_sha512.sh

╔════════════════════════════════════════════════════╗
║  Ventoy USB Setup for Unraid Recovery             ║
╚════════════════════════════════════════════════════╝

Looking for Ventoy USB drive...
✅ Detected Unraid system
✅ Found Ventoy device: /dev/sdc1
Creating mount point: /mnt/disks/Ventoy
Mounting Ventoy partition...
✅ Successfully mounted Ventoy at /mnt/disks/Ventoy
Checking if mount is read-write...
✅ Ventoy mount is read-write

📥 SystemRescue ISO not found. Download it?
   Size: ~800MB
   Version: 12.02
Download now? (yes/no): yes

Downloading SystemRescue ISO...
✅ ISO download complete

Do you want to verify the SHA512 hash of the downloaded ISO? (recommended: yes/no): yes

📥 Downloading SHA512 hash file...
✅ SHA512 hash file downloaded

Verifying SHA512 hash...
  Computing hash of ISO file...
  Comparing hashes...
  ✅ SHA512 verification PASSED!
  Hash: a1b2c3d4e5f6...

Setting up Ventoy USB structure...
[continues...]
✅ SETUP COMPLETE!
```

## Testing on Unraid

### Verify Unraid Detection
```bash
uname -a
# Should show: Linux Nas 6.12.24-Unraid x86_64 GNU/Linux
```

### Verify Ventoy Detection
```bash
lsblk -b -P -o NAME,UUID,FSTYPE,SIZE,MOUNTPOINT,LABEL,TRAN | grep Ventoy
# Should show line with LABEL="Ventoy"
```

### Verify Mount
```bash
mount | grep Ventoy
# Should show: /dev/sdc1 on /mnt/disks/Ventoy type vfat (rw,...)
```

## Cleanup (After Script Completes)

The Ventoy partition remains mounted at `/mnt/disks/Ventoy` after the script completes. This is intentional so you can:
- Review what was created
- Make manual changes if needed
- Test the setup

To unmount when done:
```bash
umount /mnt/disks/Ventoy
```

## Integration with Unraid

### Run from User Scripts Plugin
If you have the User Scripts plugin installed:

1. Add new script in Unraid Web UI
2. Paste the setup script
3. Set to run manually
4. Click "Run Script"
5. Watch output in browser

### Run via SSH
```bash
ssh root@tower
cd /mnt/user/scripts
bash setup_ventoy_usb_with_sha512.sh
```

### Run from Terminal (Docker)
If using terminal docker container:
```bash
docker exec -it terminal bash
cd /scripts
bash setup_ventoy_usb_with_sha512.sh
```

## Summary of Changes

| Aspect | Before | After |
|--------|--------|-------|
| Unraid Detection | ❌ None | ✅ Automatic |
| Device Discovery | ❌ Manual | ✅ Automatic (lsblk) |
| Mount Point | ❌ Generic | ✅ Unraid-standard (/mnt/disks/) |
| Auto-Mount | ❌ No | ✅ Yes |
| Write Verification | ❌ No | ✅ Yes (both modes) |
| Script Filename | Mixed case | ✅ Lowercase (move_dr_to_unraid.sh) |

## Compatibility Matrix

| System | Detection | Mounting | Notes |
|--------|-----------|----------|-------|
| Unraid 6.x | ✅ Auto | ✅ Auto | Full support |
| Unraid 7.x | ✅ Auto | ✅ Auto | Ready for future |
| Ubuntu/Debian | ✅ Fallback | ⚠️ Manual | Standard mode |
| Fedora/RHEL | ✅ Fallback | ⚠️ Manual | Standard mode |
| Arch | ✅ Fallback | ⚠️ Manual | Standard mode |

## Files Updated

The following script was updated:
- [setup_ventoy_usb_with_sha512.sh](computer:///mnt/user-data/outputs/setup_ventoy_usb_with_sha512.sh)

All references to the recovery script filename updated to:
```
move_dr_to_unraid.sh
```

---

**Result:** The script now provides a **native Unraid experience** with automatic detection, mounting, and verification!
