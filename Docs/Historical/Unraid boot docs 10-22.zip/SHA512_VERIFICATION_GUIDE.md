# SHA512 Verification Feature - Documentation

## Overview

The enhanced `setup_ventoy_usb_with_sha512.sh` script now includes comprehensive SHA512 hash verification to ensure the integrity of your SystemRescue ISO file. This protects against corrupted downloads and potential tampering.

## What's New

### Automatic SHA512 Hash Verification
- Downloads the official `.sha512` file from SystemRescue project
- Computes and compares hashes automatically
- Provides clear pass/fail indicators
- Handles multiple scenarios intelligently

## User Prompts & Scenarios

### Scenario 1: ISO Already in Script Directory
```
✅ SystemRescue ISO found locally: /path/to/systemrescue-12.02-amd64.iso

Do you want to verify the SHA512 hash of this ISO? (yes/no):
```

**If YES:**
- Downloads `.sha512` file if not present
- Computes hash of local ISO
- Compares with expected hash
- **FAILS:** Exits with error if mismatch
- **PASSES:** Continues with setup

**If NO:**
- Skips verification (shows warning)
- Proceeds with existing ISO

---

### Scenario 2: ISO Already on Ventoy USB
```
✅ SystemRescue ISO already exists on Ventoy USB
   Location: /media/Ventoy/systemrescue-12.02-amd64.iso

Do you want to verify the SHA512 hash of the ISO on USB? (yes/no):
```

**If YES:**
- Downloads `.sha512` file if needed
- Verifies ISO directly on USB
- **FAILS:** Offers to delete and re-download
- **PASSES:** Uses existing ISO

**If NO:**
- Skips verification
- Uses existing ISO on USB

---

### Scenario 3: Downloading Fresh ISO
```
📥 SystemRescue ISO not found. Download it?
   Size: ~800MB
   Version: 12.02
Download now? (yes/no):
```

**If YES (downloads), then asks:**
```
Do you want to verify the SHA512 hash of the downloaded ISO? (recommended: yes/no):
```

**If YES:**
- Downloads `.sha512` file
- Verifies downloaded ISO immediately
- **FAILS:** Deletes corrupted file and exits
- **PASSES:** Continues with setup

**If NO:**
- Shows warning
- Proceeds with unverified ISO

---

## Hash Verification Process

### What Happens During Verification

1. **Check for sha512sum Command**
   ```
   Verifying SHA512 hash...
   ```
   - Ensures `sha512sum` is installed
   - Exits if missing

2. **Compute Hash**
   ```
   Computing hash of ISO file...
   ```
   - Calculates SHA512 of the ISO
   - Shows progress

3. **Compare Hashes**
   ```
   Comparing hashes...
   ✅ SHA512 verification PASSED!
   Hash: 1a2b3c4d5e6f7g8h...9i0j1k2l3m4n5o6p
   ```
   OR
   ```
   ❌ SHA512 verification FAILED!
   Expected: 1a2b3c4d5e6f...
   Computed: 9z8y7x6w5v4u...
   
   ⚠️  CRITICAL ERROR: Hash mismatch detected!
   The ISO file may be corrupted or tampered with.
   Please re-download the ISO and try again.
   ```

### On Hash Failure

The script will:
1. **Stop execution immediately**
2. **Display clear error message**
3. **Show first/last 16 chars of both hashes**
4. **Recommend re-downloading**
5. **Exit with error code 1**

## File Structure

### Downloaded Files
```
script-directory/
├── setup_ventoy_usb_with_sha512.sh
├── move_DR_to_UNRAID.sh
├── systemrescue-12.02-amd64.iso          (if downloaded)
└── systemrescue-12.02-amd64.iso.sha512   (if verification requested)
```

### SHA512 File Format
The `.sha512` file contains:
```
<128-character-hash>  systemrescue-12.02-amd64.iso
```

Example:
```
a1b2c3d4e5f6...  systemrescue-12.02-amd64.iso
```

## Command Line Behavior

### Normal Flow with Verification
```bash
$ bash setup_ventoy_usb_with_sha512.sh

Looking for Ventoy USB drive...
✅ Found Ventoy USB at: /media/username/Ventoy

✅ SystemRescue ISO found locally: ./systemrescue-12.02-amd64.iso

Do you want to verify the SHA512 hash of this ISO? (yes/no): yes

📥 SHA512 hash file not found locally. Downloading...
✅ SHA512 hash file downloaded

Verifying SHA512 hash...
  Computing hash of ISO file...
  Comparing hashes...
  ✅ SHA512 verification PASSED!
  Hash: 1a2b3c4d5e6f7g8h...9i0j1k2l3m4n5o6p

Setting up Ventoy USB structure...
[continues with setup]
```

### Failed Verification Example
```bash
Do you want to verify the SHA512 hash of this ISO? (yes/no): yes

Verifying SHA512 hash...
  Computing hash of ISO file...
  Comparing hashes...
  ❌ SHA512 verification FAILED!
  Expected: 1a2b3c4d5e6f7g8h...correct_hash_end
  Computed: 9z8y7x6w5v4u3t2s...wrong_hash_end

  ⚠️  CRITICAL ERROR: Hash mismatch detected!
  The ISO file may be corrupted or tampered with.
  Please re-download the ISO and try again.

🛑 CRITICAL: Hash verification failed!
   Cannot proceed with a potentially corrupted ISO.
```

## Security Benefits

### Why SHA512 Verification Matters

1. **Detects Corrupted Downloads**
   - Network interruptions
   - Partial downloads
   - Disk errors during download

2. **Prevents Tampering**
   - Malicious modifications
   - Man-in-the-middle attacks
   - Compromised ISO files

3. **Ensures Integrity**
   - Exact file verification
   - Cryptographically secure
   - Industry standard practice

### Best Practices

✅ **ALWAYS verify hashes when:**
- Downloading from internet
- Using ISO for the first time
- ISO has been sitting around for a while
- Setting up security-critical systems

⚠️ **Consider skipping only when:**
- You've already verified it recently
- Working in a trusted offline environment
- Time is extremely critical (not recommended)

## Troubleshooting

### "sha512sum command not found"
```bash
# Ubuntu/Debian
sudo apt-get install coreutils

# Fedora/RHEL
sudo dnf install coreutils

# Already installed on most Linux systems
```

### "Failed to download SHA512 hash file"
**Solution 1:** Download manually
```bash
wget https://sourceforge.net/projects/systemrescuecd/files/sysresccd-x86/12.02/systemrescue-12.02-amd64.iso.sha512/download \
     -O systemrescue-12.02-amd64.iso.sha512
```

**Solution 2:** Get from official site
- Visit: https://www.system-rescue.org/Download/
- Download the `.sha512` file manually
- Place in same directory as script

### Verification Takes Long Time
- Normal for 800MB files
- SHA512 computation is CPU-intensive
- Usually takes 30-60 seconds on modern hardware
- Progress is shown during computation

### Hash Keeps Failing
**Possible causes:**
1. **Download was corrupted**
   - Delete ISO and re-download
   
2. **Wrong version mismatch**
   - Ensure ISO version matches script version (12.02)
   - Check `SYSRESCUE_VER` variable in script
   
3. **Wrong .sha512 file**
   - Re-download the `.sha512` file
   - Ensure it matches the ISO version

## Version Management

### Updating to New SystemRescue Version

When a new SystemRescue version is released:

1. **Update the script variables:**
   ```bash
   SYSRESCUE_VER="12.03"  # Change version number
   ```

2. **URLs auto-update:**
   ```bash
   SYSRESCUE_ISO="systemrescue-${SYSRESCUE_VER}-amd64.iso"
   SYSRESCUE_SHA512="${SYSRESCUE_ISO}.sha512"
   ```

3. **Run script normally:**
   - Will download new version
   - Will download matching `.sha512`
   - Will verify automatically

## Comparison with Original Script

### Original Script (setup_ventoy_usb.sh)
- ❌ No hash verification
- ❌ No integrity checking
- ⚠️ Risk of using corrupted ISOs

### Enhanced Script (setup_ventoy_usb_with_sha512.sh)
- ✅ Full SHA512 verification
- ✅ Multiple verification scenarios
- ✅ User-controlled (can skip if needed)
- ✅ Automatic .sha512 download
- ✅ Clear pass/fail indicators
- ✅ Prevents proceeding with bad ISOs

## Examples

### Example 1: Fresh Setup with Verification
```bash
# Download and verify everything
bash setup_ventoy_usb_with_sha512.sh

# Answer "yes" to all verification prompts
# Result: Fully verified, secure setup
```

### Example 2: Quick Setup (Skip Verification)
```bash
# Already have verified ISO
bash setup_ventoy_usb_with_sha512.sh

# Answer "no" to verification prompts
# Result: Faster setup, uses existing ISO
```

### Example 3: Verify Existing USB ISO
```bash
# Check if ISO on USB is still good
bash setup_ventoy_usb_with_sha512.sh

# ISO found on USB
# Answer "yes" to verify USB ISO
# Result: Confidence in USB integrity
```

## Summary

The SHA512 verification feature provides:
- 🔒 **Security**: Cryptographic integrity checking
- 🛡️ **Safety**: Prevents corrupted/tampered ISOs
- 🎯 **Flexibility**: User-controlled verification
- 📊 **Transparency**: Clear feedback on verification status
- ⚡ **Intelligence**: Handles multiple scenarios automatically

**Recommendation:** Always verify hashes when downloading ISOs from the internet. It takes an extra minute but ensures your recovery environment is trustworthy.

---

**Related Files:**
- [setup_ventoy_usb_with_sha512.sh](computer:///mnt/user-data/outputs/setup_ventoy_usb_with_sha512.sh) - Enhanced script with verification
- Original setup_ventoy_usb.sh - Basic script without verification
